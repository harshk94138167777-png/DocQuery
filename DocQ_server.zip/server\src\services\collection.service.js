const Collection = require('../models/Collection');
const CollectionMember = require('../models/CollectionMember');

class CollectionService {
  static async create(data, userId) {
    const collection = await Collection.create({ ...data, ownerId: userId, memberCount: 1 });
    await CollectionMember.create({ collectionId: collection._id, userId, role: 'owner', invitedBy: userId });
    return collection.toObject();
  }

  static async getUserCollections(userId) {
    const memberships = await CollectionMember.find({ userId }).lean();
    const collectionIds = memberships.map((m) => m.collectionId);
    const collections = await Collection.find({ _id: { $in: collectionIds }, deletedAt: null }).sort({ updatedAt: -1 }).lean();
    const roleMap = new Map(memberships.map((m) => [m.collectionId.toString(), m.role]));
    return collections.map((c) => ({ ...c, _id: c._id.toString(), userRole: roleMap.get(c._id.toString()) || 'viewer' }));
  }

  static async getById(collectionId) { return Collection.findOne({ _id: collectionId, deletedAt: null }).lean(); }

  static async update(collectionId, data) {
    return Collection.findOneAndUpdate({ _id: collectionId, deletedAt: null }, { $set: data }, { new: true }).lean();
  }

  static async softDelete(collectionId) {
    await Collection.updateOne({ _id: collectionId }, { $set: { deletedAt: new Date() } });
  }

  static async addMember(collectionId, userId, role, invitedBy) {
    await CollectionMember.create({ collectionId, userId, role, invitedBy });
    await Collection.updateOne({ _id: collectionId }, { $inc: { memberCount: 1 } });
  }

  static async removeMember(collectionId, userId) {
    await CollectionMember.deleteOne({ collectionId, userId });
    await Collection.updateOne({ _id: collectionId }, { $inc: { memberCount: -1 } });
  }

  static async updateMemberRole(collectionId, userId, role) {
    await CollectionMember.updateOne({ collectionId, userId }, { $set: { role } });
  }

  static async getMembers(collectionId) {
    return CollectionMember.find({ collectionId }).populate('userId', 'email displayName avatarUrl').lean();
  }
}

module.exports = { CollectionService };
