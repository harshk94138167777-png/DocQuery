const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const { env } = require('./config/env');
const { connectDB } = require('./config/database');
const { connectRedis } = require('./config/redis');
const { errorHandler } = require('./middleware/errorHandler');
const { createDocumentProcessorWorker } = require('./workers/documentProcessor.worker');
const routes = require('./routes');
const { logger } = require('./utils/logger');

const app = express();

app.use(helmet());
app.use(cors({ origin: env.CLIENT_URL, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use('/api', routes);

app.use(errorHandler);

const startServer = async () => {
  try {
    await connectDB();
    await connectRedis();
    createDocumentProcessorWorker();
    
    app.listen(env.PORT || 3000, () => {
      logger.info(`Server running on port ${env.PORT || 3000} in ${env.NODE_ENV || 'development'} mode`);
    });
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
