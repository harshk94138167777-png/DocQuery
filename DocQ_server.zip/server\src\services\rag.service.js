const { EmbeddingService } = require('./embedding.service');
const { VectorSearchService } = require('./vectorSearch.service');
const { LLMService } = require('./llm.service');
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');
const Document = require('../models/Document');

const RAG_SYSTEM_PROMPT = `You are DocQ, an AI assistant that answers questions based on the user's uploaded documents.
RULES:
1. ONLY answer based on the provided context. If the answer is not in the context, say "I couldn't find information about that in your documents."
2. Cite sources using [Source N] notation.
3. Be concise and accurate. Use markdown.
4. Synthesize from multiple sources when relevant.
5. Never make up information not in the context.
CONTEXT:\n`;

class RAGService {
  static async query(question, collectionId, conversationId, userId, res, systemPrompt) {
    const startTime = Date.now();
    const queryEmbedding = await EmbeddingService.embedSingle(question);
    const searchResults = await VectorSearchService.search(queryEmbedding, collectionId);
    const context = await this.buildContext(searchResults);
    const citations = await this.buildCitations(searchResults);

    const history = await Message.find({ conversationId }).sort({ createdAt: -1 }).limit(10).lean();
    const messages = [
      { role: 'system', content: (systemPrompt || RAG_SYSTEM_PROMPT) + context },
      ...history.reverse().map((m) => ({ role: m.role, content: m.content })),
      { role: 'user', content: question },
    ];

    await Message.create({ conversationId, role: 'user', content: question, citations: [] });

    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write(`data: ${JSON.stringify({ type: 'citations', citations })}\n\n`);

    const fullResponse = await LLMService.streamResponse(messages, res);

    const processingTimeMs = Date.now() - startTime;
    await Message.create({ conversationId, role: 'assistant', content: fullResponse, citations, processingTimeMs });
    await Conversation.updateOne({ _id: conversationId }, { $inc: { messageCount: 2 }, $set: { lastMessageAt: new Date() } });

    const convo = await Conversation.findById(conversationId);
    if (convo && convo.messageCount <= 2 && convo.title === 'New Conversation') {
      const title = question.length > 60 ? question.substring(0, 57) + '...' : question;
      await Conversation.updateOne({ _id: conversationId }, { $set: { title } });
    }

    res.write(`data: ${JSON.stringify({ type: 'done', processingTimeMs })}\n\n`);
    res.end();
  }

  static async buildContext(results) {
    if (results.length === 0) return '\nNo relevant documents found.\n';
    const docIds = [...new Set(results.map((r) => r.documentId))];
    const docs = await Document.find({ _id: { $in: docIds } }).lean();
    const docMap = new Map(docs.map((d) => [d._id.toString(), d.fileName]));
    return results.map((r, i) => `\n[Source ${i + 1}] (${docMap.get(r.documentId) || 'Unknown'}${r.pageNumber ? `, Page ${r.pageNumber}` : ''}):\n${r.content}\n`).join('\n');
  }

  static async buildCitations(results) {
    const docIds = [...new Set(results.map((r) => r.documentId))];
    const docs = await Document.find({ _id: { $in: docIds } }).lean();
    const docMap = new Map(docs.map((d) => [d._id.toString(), d.fileName]));
    return results.map((r) => ({ chunkId: r.chunkId, documentId: r.documentId, documentName: docMap.get(r.documentId) || 'Unknown', pageNumber: r.pageNumber, snippet: r.content.substring(0, 200), relevanceScore: r.score }));
  }
}

module.exports = { RAGService };
